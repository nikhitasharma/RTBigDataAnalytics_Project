package modelBuilder

import java.io.File
import javax.sound.sampled.AudioInputStream

import jAudioFeatureExtractor.AudioFeatures._
import jAudioFeatureExtractor.jAudioTools.AudioSamples
import org.apache.spark.mllib.evaluation.MulticlassMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.tree.DecisionTree
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.{Row, SQLContext}
import org.apache.spark.ml.classification.{LogisticRegression, OneVsRest}
import org.apache.spark.mllib.evaluation.MulticlassMetrics
import org.apache.spark.mllib.util.MLUtils
import org.apache.log4j.{Level, Logger}
import org.apache.spark.mllib.evaluation.MulticlassMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.tree.DecisionTree
import org.apache.spark.{SparkConf, SparkContext}



object AudioClassification {

  var TRAINING_PATH = "data/TrainingData_Set.txt"
  var TESTING_PATH = "data/Testing_Set.txt"


  val AUDIO_CATEGORIES = List("music", "speech","other", "bird")
 // val AUDIO_CATEGORIES = List("Doorbell", "Doorknock","Telephone","Dogbark","Siren","traffic","bike","ambulance","train","car")

  def main(args: Array[String]) {

     /*if(args.length < 1)
      {
        println("Usage <training path>")
      }
    else
       TRAINING_PATH = args(0) */

    System.setProperty("hadoop.home.dir", "C:\\winutils")
    val sparkConf = new SparkConf().setMaster("local[*]").setAppName("SparkDecisionTree").set("spark.driver.memory", "4g")
    val sc = new SparkContext(sparkConf)

    val train = sc.textFile(TRAINING_PATH)
    val X_train = train.map(line => {
      val parts = line.split(':')
      println(AUDIO_CATEGORIES.indexOf(parts(0)).toDouble, Vectors.dense(parts(1).split(';').map(_.toDouble)))
      LabeledPoint(AUDIO_CATEGORIES.indexOf(parts(0)).toDouble, Vectors.dense(parts(1).split(';').map(_.toDouble)))

    })

    val test = sc.textFile(TESTING_PATH)
    val X_test = test.map(line => {
      val parts = line.split(':')
      println(AUDIO_CATEGORIES.indexOf(parts(0)).toDouble, Vectors.dense(parts(1).split(';').map(_.toDouble)))
      LabeledPoint(AUDIO_CATEGORIES.indexOf(parts(0)).toDouble, Vectors.dense(parts(1).split(';').map(_.toDouble)))

    })

    val numClasses = 4
    val categoricalFeaturesInfo = Map[Int, Int]()
    val impurity = "gini"
    val maxDepth = 20
    val maxBins = 32

    val model = DecisionTree.trainClassifier(X_train, numClasses, categoricalFeaturesInfo,
      impurity, maxDepth, maxBins)
    System.out.println(model.toDebugString)

    val classify1 = X_test.map { line =>
      val prediction = model.predict(line.features)
      (line.label, prediction)
    }

    val prediction1 = classify1.groupBy(_._1).map(f => {
      var fuzzy_Pred = Array(0, 0, 0)
      f._2.foreach(ff => {
        fuzzy_Pred(ff._2.toInt) += 1
      })
      var count = 0.0
      fuzzy_Pred.foreach(f => {
        count += f
      })
      var i = -1
      var maxIndex = 3
      val max = fuzzy_Pred.max
      val pp = fuzzy_Pred.map(f => {
        val p = f * 100 / count
        i = i + 1
        if(f == max)
          maxIndex=i
        (i, p)
      })
      (f._1, pp, maxIndex)
    })
    prediction1.foreach(f => {
      println("\n\n\n" + f._1 + " : " + f._2.mkString(";\n"))
    })
    val y = prediction1.map(f => {
      (f._1, f._3.toDouble)
    })

    y.collect().foreach(println(_))

    val metrics = new MulticlassMetrics(y)

    //println("Accuracy:" + metrics.)

    println("Confusion Matrix:")
    println(metrics.confusionMatrix)
    println("Confusion Matrix:")


   /* val labelAndPreds = X_test.map { point =>
      val prediction = model.predict(point.features)
      (point.label, prediction) */

    //val prediction = model.transform(TESTING_PATH).select()

   // val predictionAndLabel = test.map(p => (model.predict(p.features), p.label))



    //val metrics= new MulticlassMetrics(prediction)



    modelBuilder.MongoCall.insertIntoMongoDB(model.toDebugString)

  }

}
